# GCP Cloud Run Module

Simple, production-ready Cloud Run module for deploying containerized applications.

## Features

- ✅ Cloud Run (serverless containers)
- ✅ Auto-scaling
- ✅ Health checks
- ✅ HTTPS endpoints
- ✅ Service account management
- ✅ Secure defaults

## Usage

```hcl
module "web_app" {
  source = "./packages/compute/gcp/terraform"

  app_name        = "my-web-app"
  project_id      = "my-gcp-project"
  container_image = "gcr.io/my-gcp-project/my-app:latest"
  container_port  = 8080
  region          = "us-central1"

  cpu    = 1000  # 1 vCPU
  memory = 512   # 512 MB

  min_instances = 0  # Scale to zero
  max_instances = 10

  environment_variables = {
    DATABASE_URL = "postgres://..."
    API_KEY      = "secret"
  }

  labels = {
    environment = "production"
    project     = "my-app"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| app_name | Name of the application | `string` | n/a | yes |
| project_id | GCP project ID | `string` | n/a | yes |
| container_image | Docker container image URL | `string` | n/a | yes |
| container_port | Port the container listens on | `number` | `8080` | no |
| region | GCP region | `string` | `"us-central1"` | no |
| cpu | CPU in milliCPU (1000 = 1 vCPU) | `number` | `1000` | no |
| memory | Memory in MB | `number` | `512` | no |
| min_instances | Minimum instances | `number` | `0` | no |
| max_instances | Maximum instances | `number` | `10` | no |
| health_check_path | HTTP health check endpoint | `string` | `"/health"` | no |
| environment_variables | Environment variables | `map(string)` | `{}` | no |
| allow_public_access | Allow public access | `bool` | `true` | no |
| labels | Additional resource labels | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| service_url | Public URL of the service |
| service_name | Name of the Cloud Run service |
| service_account_email | Email of the service account |

## Adding Cloud Storage Access

```hcl
module "web_app" {
  source = "./packages/compute/gcp/terraform"
  # ... other config ...
}

module "storage" {
  source = "./packages/storage/gcp/terraform"
  bucket_name = "my-app-data"
  project_id  = "my-gcp-project"
}

# Grant the application access to the bucket
resource "google_storage_bucket_iam_member" "app_access" {
  bucket = module.storage.bucket_name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${module.web_app.service_account_email}"
}
```

## CPU and Memory

Cloud Run supports flexible CPU/memory combinations:
- CPU: 1000-8000 milliCPU (1-8 vCPUs)
- Memory: 128MB-32GB

## Scale to Zero

Setting `min_instances = 0` enables scaling to zero during idle periods, reducing costs. First request after idle period will have cold start (~1-3 seconds).

## Cost Optimization

- Use `min_instances = 0` to scale to zero
- Right-size CPU and memory for your workload
- Use concurrency limits to control scaling behavior
