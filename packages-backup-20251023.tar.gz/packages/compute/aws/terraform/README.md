# AWS ECS Fargate Module

Simple, production-ready ECS Fargate module for deploying containerized applications.

## Features

- ✅ ECS Fargate (serverless containers)
- ✅ Application Load Balancer
- ✅ Auto-scaling ready
- ✅ CloudWatch Logs integration
- ✅ Health checks
- ✅ Secure defaults

## Usage

```hcl
module "web_app" {
  source = "./packages/compute/aws/terraform"

  app_name        = "my-web-app"
  container_image = "123456789.dkr.ecr.us-east-1.amazonaws.com/my-app:latest"
  container_port  = 8080
  region          = "us-east-1"

  cpu    = 512
  memory = 1024

  environment_variables = {
    DATABASE_URL = "postgres://..."
    API_KEY      = "secret"
  }

  tags = {
    Environment = "production"
    Project     = "my-app"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| app_name | Name of the application | `string` | n/a | yes |
| container_image | Docker container image URL | `string` | n/a | yes |
| container_port | Port the container listens on | `number` | `8080` | no |
| region | AWS region | `string` | `"us-east-1"` | no |
| cpu | CPU units (256, 512, 1024, etc.) | `number` | `256` | no |
| memory | Memory in MB | `number` | `512` | no |
| desired_count | Number of instances | `number` | `1` | no |
| health_check_path | HTTP health check endpoint | `string` | `"/health"` | no |
| environment_variables | Environment variables | `map(string)` | `{}` | no |
| tags | Additional resource tags | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| service_url | Public URL of the application |
| load_balancer_dns | DNS name of the load balancer |
| cluster_name | Name of the ECS cluster |
| service_name | Name of the ECS service |
| task_role_arn | ARN of the task role (for adding permissions) |
| log_group_name | CloudWatch log group name |

## Adding S3 Access

```hcl
module "web_app" {
  source = "./packages/compute/aws/terraform"
  # ... other config ...
}

module "storage" {
  source = "./packages/storage/aws/terraform"
  bucket_name = "my-app-data"
}

# Grant the application access to the bucket
resource "aws_iam_role_policy" "app_storage_access" {
  role = module.web_app.task_role_arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ]
      Resource = "${module.storage.bucket_arn}/*"
    }]
  })
}
```

## CPU and Memory Combinations

Valid combinations for Fargate:

| CPU | Memory |
|-----|--------|
| 256 | 512MB, 1GB, 2GB |
| 512 | 1GB, 2GB, 3GB, 4GB |
| 1024 | 2GB, 3GB, 4GB, 5GB, 6GB, 7GB, 8GB |
| 2048 | 4GB-16GB (1GB increments) |
| 4096 | 8GB-30GB (1GB increments) |
