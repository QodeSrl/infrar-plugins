# AWS Secrets Manager Module

Simple module for managing secrets in AWS Secrets Manager.

## Features

- ✅ Automatic encryption
- ✅ Version management
- ✅ Recovery window for deleted secrets
- ✅ IAM integration

## Usage

```hcl
module "database_password" {
  source = "./packages/secrets/aws/terraform"

  secret_name  = "my-app/database/password"
  description  = "Database password for my-app"
  secret_value = "super-secret-password"  # Better: use variable or data source

  tags = {
    Environment = "production"
    Application = "my-app"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| secret_name | Name of the secret | `string` | n/a | yes |
| description | Description of the secret | `string` | `""` | no |
| secret_value | The secret value (sensitive) | `string` | `null` | no |
| recovery_window_days | Recovery window before deletion | `number` | `7` | no |
| tags | Additional resource tags | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| secret_arn | ARN of the secret |
| secret_name | Name of the secret |

## Granting Access to ECS Task

```hcl
module "database_password" {
  source      = "./packages/secrets/aws/terraform"
  secret_name = "my-app/db/password"
}

module "web_app" {
  source = "./packages/compute/aws/terraform"
  # ... other config ...
}

# Grant task access to the secret
resource "aws_iam_role_policy" "secret_access" {
  role = module.web_app.task_role_arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "secretsmanager:GetSecretValue"
      ]
      Resource = module.database_password.secret_arn
    }]
  })
}
```

## Best Practices

- Use recovery window (7-30 days) for production secrets
- Rotate secrets regularly
- Use IAM policies for least-privilege access
- Never commit secret values to version control
