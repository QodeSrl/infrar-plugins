# GCP Secret Manager Module

Simple module for managing secrets in GCP Secret Manager.

## Features

- ✅ Automatic encryption
- ✅ Version management
- ✅ Automatic replication
- ✅ IAM integration

## Usage

```hcl
module "database_password" {
  source = "./packages/secrets/gcp/terraform"

  secret_name  = "database-password"
  project_id   = "my-gcp-project"
  secret_value = "super-secret-password"  # Better: use variable or data source

  labels = {
    environment = "production"
    application = "my-app"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| secret_name | Name of the secret | `string` | n/a | yes |
| project_id | GCP project ID | `string` | n/a | yes |
| secret_value | The secret value (sensitive) | `string` | `null` | no |
| labels | Additional resource labels | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| secret_id | ID of the secret |
| secret_name | Name of the secret |

## Granting Access to Cloud Run Service

```hcl
module "database_password" {
  source      = "./packages/secrets/gcp/terraform"
  secret_name = "database-password"
  project_id  = "my-gcp-project"
}

module "web_app" {
  source = "./packages/compute/gcp/terraform"
  # ... other config ...
}

# Grant service account access to the secret
resource "google_secret_manager_secret_iam_member" "app_access" {
  secret_id = module.database_password.secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${module.web_app.service_account_email}"
}
```

## Best Practices

- Use automatic replication for high availability
- Rotate secrets regularly
- Use IAM policies for least-privilege access
- Never commit secret values to version control
- Use Secret Manager API versions for updates
