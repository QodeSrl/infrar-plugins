# AWS S3 Bucket Module

Simple, production-ready S3 bucket module for Infrar deployments.

## Features

- ✅ Server-side encryption (AES256)
- ✅ Public access blocked by default
- ✅ Optional versioning
- ✅ Optional CORS configuration
- ✅ Optional lifecycle rules
- ✅ Secure defaults

## Usage

```hcl
module "storage" {
  source = "./packages/storage/aws/terraform"

  bucket_name        = "my-app-data"
  versioning_enabled = true

  lifecycle_rules = [{
    id     = "archive-old-data"
    status = "Enabled"
    transitions = [{
      days          = 90
      storage_class = "GLACIER"
    }]
    expiration = {
      days = 365
    }
  }]

  tags = {
    Environment = "production"
    Project     = "my-app"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| bucket_name | Name of the S3 bucket | `string` | n/a | yes |
| versioning_enabled | Enable object versioning | `bool` | `false` | no |
| cors_rules | CORS configuration rules | `list(object)` | `[]` | no |
| lifecycle_rules | Lifecycle management rules | `list(object)` | `[]` | no |
| tags | Additional resource tags | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| bucket_name | Name of the S3 bucket |
| bucket_arn | ARN of the S3 bucket |
| bucket_url | S3 URL of the bucket |

## Example with CORS

```hcl
module "storage" {
  source = "./packages/storage/aws/terraform"

  bucket_name = "my-app-uploads"

  cors_rules = [{
    allowed_headers = ["*"]
    allowed_methods = ["GET", "PUT", "POST"]
    allowed_origins = ["https://example.com"]
    max_age_seconds = 3600
  }]
}
```
